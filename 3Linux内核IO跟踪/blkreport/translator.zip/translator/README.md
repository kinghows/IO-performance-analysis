# translator - Easy translation of strings in LaTeX

The translator package is a LaTeX package that provides a flexible
mechanism for translating individual words into different languages. For
example, it can be used to translate a word like figure into, say, the
German word Abbildung. Such a translation mechanism is useful when the
author of some package would like to localize the package such that
texts are correctly translated into the language preferred by the user.
The translator package is not intended to be used to automatically
translate more than a few words.
